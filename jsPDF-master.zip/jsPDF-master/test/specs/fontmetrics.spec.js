/* global describe, it, expect, jsPDF */

describe("Module: Standard Font Metrics", () => {
  beforeAll(loadGlobals);
  it("uncompress", () => {
    expect(
      jsPDF.API.__fontmetrics__.uncompress(
        "{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"
      )
    ).toEqual({ widths: { 0: 60, fof: 100 }, kerning: { fof: -100 } });
  });
  it("uncompress fail", () => {
    expect(function() {
      jsPDF.API.__fontmetrics__.uncompress({
        widths: { 0: 60, fof: 100 },
        kerning: { fof: -100 }
      });
    }).toThrow(new Error("Invalid argument passed to uncompress."));
    expect(function() {
      jsPDF.API.__fontmetrics__.compress({
        widths: "invalid",
        kerning: { fof: -100 }
      });
    }).toThrow(new Error("Don't know what to do with value type string."));
  });
  it("compress", () => {
    expect(
      jsPDF.API.__fontmetrics__.compress({
        widths: { 0: 60, fof: 100 },
        kerning: { fof: -100 }
      })
    ).toEqual("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}");
  });
  it("compress and uncompress", () => {
    var value = { widths: { 0: 60, fof: 100 }, kerning: { fof: -100 } };
    expect(
      jsPDF.API.__fontmetrics__.uncompress(
        jsPDF.API.__fontmetrics__.compress(value)
      )
    ).toEqual(value);
  });
  it("uncompress and compress", () => {
    var value =
      "{19m8n201n9q201o9r201s9l201t9m201u8m201w9n201x9o201y8o202k8q202l8r202m9p202q8p20aw8k203k8t203t8v203u9v2cq8s212m9t15m8w15n9w2dw9s16k8u16l9u17s9z17x8y17y9y}";
    expect(
      jsPDF.API.__fontmetrics__.uncompress(
        jsPDF.API.__fontmetrics__.compress(
          jsPDF.API.__fontmetrics__.uncompress(value)
        )
      )
    ).toEqual(jsPDF.API.__fontmetrics__.uncompress(value));
    value =
      "{'widths'{k3n2q4ycx2l201n3m201o6o201s2l201t2l201u2l201w2w201x2w201y2w2k1t2l2l202m2n2n3m2o3m2p5n202q6o2r1m2s2l2t2l2u3m2v3s2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v1w3w3s3x3s3y3s3z2w4k5w4l4s4m4m4n4m4o4s4p3x4q3r4r4s4s4s4t2l4u2r4v4s4w3x4x5t4y4s4z4s5k3r5l4s5m4m5n3r5o3x5p4s5q4s5r5y5s4s5t4s5u3x5v2l5w1w5x2l5y2z5z3m6k2l6l2w6m3m6n2w6o3m6p2w6q2l6r3m6s3m6t1w6u1w6v3m6w1w6x4y6y3m6z3m7k3m7l3m7m2l7n2r7o1w7p3m7q3m7r4s7s3m7t3m7u2w7v3k7w1o7x3k7y3q202l3mcl4sal2lam3man3mao3map3mar3mas2lat4wau1vav3maw3say4waz2lbk2sbl3s'fof'6obo2lbp3mbq2xbr1tbs2lbu1zbv3mbz2wck4s202k3mcm4scn4sco4scp4scq5tcr4mcs3xct3xcu3xcv3xcw2l2m2tcy2lcz2ldl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek2wel2wem2wen2weo2wep2weq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr3sfs3mft3mfu3mfv3mfw3mfz3m203k6o212m6m2dw2l2cq2l3t3m3u1w17s4s19m3m}'kerning'{cl{4qs5ku17sw5ou5qy5rw201ss5tw201ws}201s{201ss}201t{ckw4lwcmwcnwcowcpwclw4wu201ts}2k{201ts}2w{4qs5kw5os5qx5ru17sx5tx}2x{17sw5tw5ou5qu}2y{4qs5kw5os5qx5ru17sx5tx}'fof'-6o7t{ckuclucmucnucoucpu4lu5os5rs}3u{17su5tu5qs}3v{17su5tu5qs}7p{17sw5tw5qs}ck{4qs5ku17sw5ou5qy5rw201ss5tw201ws}4l{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cm{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cn{4qs5ku17sw5ou5qy5rw201ss5tw201ws}co{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cp{4qs5ku17sw5ou5qy5rw201ss5tw201ws}6l{17su5tu5os5qw5rs}17s{2ktclvcmvcnvcovcpv4lv4wuckv}5o{ckwclwcmwcnwcowcpw4lw4wu}5q{ckyclycmycnycoycpy4ly4wu5ms}5r{cktcltcmtcntcotcpt4lt4ws}5t{2ktclvcmvcnvcovcpv4lv4wuckv}7q{cksclscmscnscoscps4ls}6p{17su5tu5qw5rs}ek{5qs5rs}el{17su5tu5os5qw5rs}em{17su5tu5os5qs5rs}en{17su5qs5rs}eo{5qs5rs}ep{17su5tu5os5qw5rs}es{5qs}et{17su5tu5qw5rs}eu{17su5tu5qs5rs}ev{5qs}6z{17sv5tv5os5qx5rs}fm{5os5qt5rs}fn{17sv5tv5os5qx5rs}fo{17sv5tv5os5qx5rs}fp{5os5qt5rs}fq{5os5qt5rs}7r{ckuclucmucnucoucpu4lu5os}fs{17sv5tv5os5qx5rs}ft{17ss5ts5qs}fu{17sw5tw5qs}fv{17sw5tw5qs}fw{17ss5ts5qs}fz{ckuclucmucnucoucpu4lu5os5rs}}}";
    expect(
      jsPDF.API.__fontmetrics__.uncompress(
        jsPDF.API.__fontmetrics__.compress(
          jsPDF.API.__fontmetrics__.uncompress(value)
        )
      )
    ).toEqual(jsPDF.API.__fontmetrics__.uncompress(value));
  });
});
